    <!-- Contact Section -->
    <section id="contact" class="second-section text-center">
        <div class="container">
            <div class="row">
                <div class="col-lg-8 mx-auto">
                    <h2>Contacts</h2>
                    <hr>
                    <br>
                    <p>
                        +372 5567 1134 &#160 | &#160 +372 5559 0468<br>
                        <a href="mailto:ansambel.triskele@gmail.com">ansambel.triskele@gmail.com</a><br>
                        <a href="https://www.facebook.com/ansambeltriskele/" class="fa fa-facebook"></a>
                        <a href="https://www.youtube.com/channel/UCCHqMoqPVEEp_oG85SbEvaw/" class="fa fa-youtube"></a>
                    </p>
                    <br>
                    <br>
                    <p>
                        <!-- <a href="http://sircorp.ee"><img src="<?php echo get_template_directory_uri() ?>/assets/images/sircorp_logo.png" alt="..." style="max-width: 100%; max-height: 90px;" /></a><br> -->
                        <img src="<?php echo get_template_directory_uri() ?>/assets/images/sircorp_logo.png" alt="..." style="max-width: 100%; max-height: 90px;" /><br>
                        <span class="boldd">Siiri Siimer</span><br>
                        +372 501 8971<br>
                        <a href="mailto:siiri@sircorp.ee">siiri@sircorp.ee</a>
                    </p>
                </div>
            </div>
        </div>
    </section>


    <!-- Footer -->
    <footer>
        <div class="container text-center">
            <p><a href="assets/font-awesome/css/PoorlevKuup.html" style="color: white;">&copy; Triskele 2023</p>
        </div>
        <?php wp_footer(); ?>
    </footer>


    </body>

    </html>